import torch
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.optim as optim
from defense import generate_subset
from options import args_parser
from models import MLP, CNNMnist, CNNFashion_Mnist, CNNCifar,CNNCifar100
from utils import get_dataset, average_weights, exp_details

n_epochs = 3  # 循环整个训练数据集的次数
batch_size_train = 10  # 每个训练batch有多少个样本 比如有1000个样本，把这些样本分为10批，就是10个batch
batch_size_test = 1000  # 每个测试训练batch有多少个样本
learning_rate = 0.01  # 学习率：learning_rate = 0.01
momentum = 0.5
# momentum：我们把这个人从平地上放到了一个斜坡上, 只要他往下坡的方向走一点点, 由于向下的惯性, 他不自觉地就一直往下走,
# 走的弯路也变少了. 这就是 Momentum 参数更新
args = args_parser()
subset = []
log_interval = 10  # 日志输出间隔，多少次print一下
random_seed = 1  # 随机种子
torch.manual_seed(random_seed)


def train_val_test(args, train_dataset, test_dataset):
    """
    Returns train, validation and test dataloaders for a given dataset
    and user indexes.
    """
    # split indexes for train, validation, and test (80, 10, 10)


    trainloader = DataLoader(train_dataset,batch_size=args.local_bs, shuffle=True)
    testloader = DataLoader(test_dataset,batch_size=batch_size_test, shuffle=False)

    return trainloader,testloader

train_dataset, test_dataset = get_dataset(args)
train_loader,test_loader = train_val_test(args, train_dataset, test_dataset)
subset = generate_subset(train_dataset,args) #subset是一组dataloader的集合
examples = enumerate(test_dataset)
# enumerate()：遍历一个集合对象，它在遍历的同时还可以得到当前元素的索引位置。
# 遍历了列表的所有元素，并通过增加从零开始的计数器变量来为每个元素生成索引
batch_idx, (example_data, example_targets) = next(examples)

network = CNNMnist(args=args)
optimizer = optim.SGD(network.parameters(), lr=learning_rate, momentum=momentum)

train_losses = []
train_counter = []
test_losses = []
test_counter = [i * len(train_dataset) for i in range(n_epochs + 1)]


def submodel_train(epoch,i,args):
    # pytorch可以给我们提供两种方式来切换训练和评估(推断)的模式。分别是：model.train()和model.eval()
    network.train()

    # Set optimizer for the local updates
    if args.optimizer == 'sgd':
        optimizer = torch.optim.SGD(network.parameters(), lr=args.lr,
                                    weight_decay=1e-4)
    elif args.optimizer == 'adam':
        optimizer = torch.optim.Adam(network.parameters(), lr=args.lr,
                                     weight_decay=1e-4)

    # for iter in range(args.local_ep):
    for batch_idx, (data, target) in enumerate(subset[i]):
        network.zero_grad()  # 将梯度归零  梯度就表示从该点出发，函数值增长最为迅猛的方向
        output = network(data)
        cross_loss = F.cross_entropy(output, target)  # 损失函数计算损失值

        l2_regularization = 1e-4 * sum([p.abs().sum() for p in network.parameters()])
        # cross_loss = F.nll_loss(output, target)  # 损失函数计算损失值
        loss = cross_loss + l2_regularization  # L2 正则化

        loss.backward()  # 反向传播计算得到每个参数的梯度值
        optimizer.step()  # 通过梯度下降执行一步参数更新，会更新所有的参数
        if batch_idx % log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(epoch, batch_idx * len(data),
                                                                           len(train_dataset),
                                                                           100. * batch_idx / len(train_dataset),
                                                                           loss.item()))
            train_losses.append(loss.item())
            train_counter.append((batch_idx * 64) + ((epoch - 1) * len(train_dataset)))
            torch.save(network, '../Defense/save_model/model'+str(i+1)+'.pth')
            # torch.save(optimizer.state_dict(), '../save_optimizer/optimizer'+str(i)+'.pth')


def submodel_test():
    network.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():  # 所有计算得出的tensor的requires_grad都自动设置为False
        # requires_grad：是Pytorch中通用数据结构Tensor的一个属性，用于说明当前量是否需要在计算中保留对应的梯度信息
        # 我的理解是因为这是测试，不需要再对参数进行修改了
        for data, target in test_loader:
            output = network(data)
            test_loss += F.nll_loss(output, target, reduction='sum').item()
            # reduction：对计算结果采取的操作，通常我们用sum（对N个误差结果求和）, mean（对N个误差结果取平均），默认是对所有样本求loss均值
            pred = output.data.max(1, keepdim=True)[1]
            # .data.max用于找概率最大的下标
            correct += pred.eq(target.data.view_as(pred)).sum()
            # 正确的个数
    test_loss /= len(test_loader.dataset)
    test_losses.append(test_loss)
    print('\nTest set: Avg. loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))
    # Test set: Avg.loss: 0.0921, Accuracy: 9709 / 10000(97 %)

#子模型训练
if __name__ == '__main__':
    for item in subset:
        for epoch in range(1, n_epochs + 1):
            submodel_train(epoch, subset.index(item),args)
            submodel_test()
            print("*" * 60)