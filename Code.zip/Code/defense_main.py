from DCGAN.config import parse_args
from Defense.models import  CNNMnist,  CNNCifar
from Defense.utils import get_dataset, get_shadow_train_loader
from torchvision import datasets, transforms
from Defense.defense import gen_noIn
import random
import torch
from torch.utils.data import DataLoader
import numpy as np

classifier = 1
n_epochs = 3  # 循环整个训练数据集的次数
batch_size_train = 10  # 每个训练batch有多少个样本 比如有1000个样本，把这些样本分为10批，就是10个batch
batch_size_test = 1000  # 每个测试训练batch有多少个样本
learning_rate = 0.01  # 学习率：learning_rate = 0.01
momentum = 0.5  #动量更新参数
args = parse_args()
subset = []
log_interval = 10  # 日志输出间隔，多少次print一下
random_seed = 1  # 随机种子
# No_in = []
query_image_list = []  # case2 对应img PIL集合，需要进行图像处理
query_tensor_list = []  # case1 对应tensor集合

torch.manual_seed(random_seed)


####### ###### ###### ###### 模拟attack进行query的过程 ###### ###### ###### ######

#输入数据的预处理
mnist_val_transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))])

cifar_val_transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

#不同类型本地数据集的数据预处理处理
def image_transform(args,image):
    if args.dataset == 'mnist':
        img_tensor = mnist_val_transform(image)
    elif args.dataset == 'cifar':
        img_tensor = cifar_val_transform(image)

    return img_tensor

#将分解出的dataset封装成dataloader
def train_val_test(args, train_dataset, test_dataset):
    trainloader = DataLoader(train_dataset,batch_size=args.local_bs, shuffle=True)
    testloader = DataLoader(test_dataset,batch_size=batch_size_test, shuffle=False)

    return trainloader,testloader

train_dataset, test_dataset= get_dataset(args)

# train_loader,test_loader = train_val_test(args, train_dataset, test_dataset) ###### train_loader是gte shadow得到的batch读取结果，期望是由本地进行读取后放到GAN上进行训练调用
# shadow_train_loader =  get_shadow_train_loader()
# query_list = query_list_generate_ori('ori',shadow_train_loader)

if args.model == 'cnn':
    # Convolutional neural netork
    if args.dataset == 'mnist':
        model = CNNMnist(args=args)
    elif args.dataset == 'cifar':
        model = CNNCifar(args=args)

def tensor_equal(a, b):
    a_array = transform_TENSOR(a)
    b_array = transform_TENSOR(b)
    if((a_array == b_array)):
        return True
    else:
        return False

def transform_TENSOR(image_tensor): #将tensor形式转化为array
    # image_numpy_form_tensor = image_tensor.mul(255).byte()  # 将tensor中的所有像素点的值乘 255
    # image_numpy_form_tensor = np.array(image_numpy_form_tensor).transpose(1, 2, 0)
    image_numpy_form_tensor = image_tensor.numpy().tolist()
    return image_numpy_form_tensor

def submodel_predict(img_torch,i):
    model = torch.load('../Defense/save_model/model'+str(i)+'.pth')
    model.eval()

    img_torch = torch.unsqueeze(img_torch, dim=0)
    output = model(img_torch)
    return  output

def label_pridect(img_tensor,index,lis):
    # label-only 预测
    output = []
    nox = []
    pre_label = 0
    Vote = []
    a_sum = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    label = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    nox = lis[index] #取得当下元素的no-in list
    lens = nox.__len__()
    # pred_sum = np.array(list1)

    for i in nox:
        a = submodel_predict(img_tensor, i)
        b = a.detach().numpy()
        preds = b[0].tolist()
        # for num in range(0, 10):
        #     if (b[0][0] - 1) == num:
        #         label[num] += 1;
        for index, item in enumerate(b[0]):
            a_sum[index]+= b[0][index]
    for j in range(0,10):
        a_sum[j] = a_sum[j]/lens
    avg = np.array(a_sum)
    pred = avg.argmax()

    return pred



def main_defense(case,No_in, lis,query_list,train_set):
    #test部分
    #case0:单个数据
    # if case == 0:
    #     for id, (data, target) in enumerate(shadow_train_loader):
    #         if (tensor_equal(query, data)):
    #             index = id
    #             predict_label = label_pridect(query, index)
    #             print("prediect label is")
    #             print(predict_label)

    # case1：:攻击者只能通过query目标模型进行标签获取,只有ori数据
    if case == 1:
        final_dict = []
        for index,value in enumerate(query_list):
            data = train_set[index]
            predict_label = label_pridect(data,index,lis)  # 如果为本地数据就预测后进行标签偏移工作 ,index部分要进行调整，现在的dataloader是整个cifar集合
            temp = []
            temp.append(value)
            temp.append(predict_label)
            final_dict.append(temp)

        return final_dict  #(fakeLabel)

'''#cifar10
def processDataloader(args):
    query_list = []
    data_dir = '../Defense/data/cifar/'

    query_list,train_set = get_shadow_train_loader()
    No_in, lis = gen_noIn(query_list)  # 生成NO-in数组
    finalDict = main_defense(1, No_in, lis,query_list,train_set) #按顺序存的fake-label


    train_dataset = datasets.CIFAR10(data_dir, train=True, download=True,
                                      transform=transforms.Compose([
                                          transforms.Resize(64),
                                          transforms.CenterCrop(64),
                                          transforms.ToTensor(),
                                          transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
                                      ]))

    for i in range(0,10):
        dataList = []
        labelList = []
        for item in finalDict:
            if (item[1] == i):
                real_data = train_dataset.__getitem__(item[0])[0]
                dataList.append(real_data)
                labelList.append(item[1])
        data1 = []
        data1 = list(zip(dataList, labelList))
        lens = len(data1)
        res = lens//64
        data1 = data1[:64 * res]
        print(len(data1))
        datas =[]
        labels =[]
        for temp in data1:
            datas.append(temp[0])
            labels.append(temp[1])
        np.savez("../DCGAN/dataset/shadow/ganShadowTrain"+str(i)+".npz", datas, labels)

    return 0;
'''

def processDataloader(args):
    query_list = []
    data_dir = '../data/mnist/'

    query_list,train_set = get_shadow_train_loader()
    No_in, lis = gen_noIn(query_list)  # 生成NO-in数组
    finalDict = main_defense(1, No_in, lis,query_list,train_set) #按顺序存的fake-label


    train_dataset = datasets.MNIST(data_dir, train=True, download=True,
                                      transform=transforms.Compose([
                                          transforms.Resize(28),
                                          transforms.CenterCrop(28),
                                          transforms.Grayscale(),
                                          transforms.ToTensor(),
                                          transforms.Normalize((0.1307,), (0.3081,)),
                                      ]))

    for i in range(0,10):
        dataList = []
        labelList = []
        for item in finalDict:
            if (item[1] == i):
                real_data = train_dataset.__getitem__(item[0])[0]
                print("real_data_type",type(real_data))
                dataList.append(real_data)
                labelList.append(item[1])
        data1 = []
        data1 = list(zip(dataList, labelList))
        lens = len(data1)
        res = lens//64
        data1 = data1[:64 * res]
        print("len is",len(data1))
        datas =[]
        labels =[]
        for temp in data1:
            print("temp[0] type", type(temp[0]))
            datas.append(temp[0])
            labels.append(temp[1])
        np.savez("../DCGAN/dataset/shadow/ganShadowTrain"+str(i)+".npz", datas, labels)

    return 0;

def getMixPred(input):
    data_dir = '../data/mnist/'
    train_dataset = datasets.MNIST(data_dir, train=True, download=True,
                                     transform=transforms.Compose([
                                         transforms.Resize(28),
                                         transforms.CenterCrop(28),
                                         transforms.Grayscale(),
                                         transforms.ToTensor(),
                                         transforms.Normalize((0.1307,), (0.3081,)),
                                     ]))
    for i in range(len(train_dataset)):
        real_data = train_dataset.__getitem__(i)[0]
        if(real_data == input):
            index = i
    return index



if __name__ == '__main__':
    processDataloader(args)

