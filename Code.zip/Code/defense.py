import torch
import random
import numpy as np
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Dataset,Subset

class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = [int(i) for i in idxs]

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return torch.as_tensor(image), torch.tensor(label)

class DatasetFind(Dataset):
    def __init__(self, dataset, item):
        self.dataset = dataset

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        return self.idx[item]


def gen_noIn(train_dataset):
    d_len = len(train_dataset)

    # 创建一个noIn(x)列表lis
    lis = [] #生成noin(x)数据的列表
    No_in=[] #最终的用于生成数据子集的Idx

    noin1=[]
    noin2=[]
    noin3=[]
    noin4=[]
    noin5=[]
    noin6=[]
    noin7=[]
    noin8=[]

    for i in range(0,d_len):
        temp = np.random.choice(range(1,9), 5, replace=False)
        lis.append(temp)

    #获取noin的元素序号
    for i, n in enumerate(lis):
        if not (1 in n): noin1.append(i)
        if not (2 in n): noin2.append(i)
        if not (3 in n): noin3.append(i)
        if not (4 in n): noin4.append(i)
        if not (5 in n): noin5.append(i)
        if not (6 in n): noin6.append(i)
        if not (7 in n): noin7.append(i)
        if not (8 in n): noin8.append(i)

    No_in.append(noin1)
    No_in.append(noin2)
    No_in.append(noin3)
    No_in.append(noin4)
    No_in.append(noin5)
    No_in.append(noin6)
    No_in.append(noin7)
    No_in.append(noin8)
    return No_in,lis


def generate_subset(train_dataset,args):
    #使用no_in序列生成子数据集
    No_in = []
    lis = []
    No_in ,lis = gen_noIn(train_dataset) #No_in 6个列表
    subset = []
    all=0

    subset_1 = DataLoader(DatasetSplit(train_dataset, No_in[0]),
                              batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_1,all)
    subset.append(subset_1)
    subset_2 = DataLoader(DatasetSplit(train_dataset, No_in[1]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_2,all)
    subset.append(subset_2)
    subset_3 = DataLoader(DatasetSplit(train_dataset, No_in[2]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_3,all)
    subset.append(subset_3)
    subset_4 = DataLoader(DatasetSplit(train_dataset, No_in[3]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_4,all)
    subset.append(subset_4)
    subset_5 = DataLoader(DatasetSplit(train_dataset, No_in[4]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_5,all)
    subset.append(subset_5)
    subset_6 = DataLoader(DatasetSplit(train_dataset, No_in[5]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_6,all)
    subset.append(subset_6)

    subset_7 = DataLoader(DatasetSplit(train_dataset, No_in[6]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_7,all)
    subset.append(subset_7)
    subset_8 = DataLoader(DatasetSplit(train_dataset, No_in[7]),
                          batch_size=args.local_bs, shuffle=True)
    getLabelNum(subset_8,all)
    subset.append(subset_8)
    return  subset

def getLabelNum(train_dataloader,all):
    label_num = [0,0,0,0,0,0,0,0,0,0]
    #label_num = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    sum_num = 0
    for i, item in enumerate(train_dataloader):
        data, label = item
        labelArr = label.numpy()
        for y in labelArr:
            label_num[y] = label_num[y]+1
    for numa in label_num:
        sum_num += numa
    print('label:', label_num)
    print('sum:', sum_num)
    print("all",all+sum_num)

'''
def prepare_datasest(self, args, sample, train_dataset):
    trainset = []
    sample_noin = []
    subset = []
    DF = DatasetFind(sample,train_dataset)
    index  = DF.__getitem__(sample) #获取查询样本在数据集中的序号

    list,No_in = gen_noIn(train_dataset)#获得noin列表
    sample_noin = list[index] #获取查询样本的noin序列
    subset = generate_subset(train_dataset,args)#拿到分割好的数据集

    for i in sample_noin:
        trainset.append(subset[i])

    return trainset
'''
