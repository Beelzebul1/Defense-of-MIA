#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6

import copy
import pickle
import torch
import random
import numpy as np
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Dataset,Subset


def get_dataset(args):
    """ Returns train and test datasets and a user group which is a dict where
    the keys are the user index and the values are the corresponding data for
    each of those users.
    """
    print(args.dataset)
    if args.dataset == 'cifar':
        data_dir = '../Defense/data/cifar/'
        apply_transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        train_dataset = datasets.CIFAR10(data_dir, train=True, download=True,
                                       transform=apply_transform)

        test_dataset = datasets.CIFAR10(data_dir, train=False, download=True,
                                      transform=apply_transform)

    elif args.dataset == 'cifar100':
        data_dir = '../data/cifar100/'
        apply_transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        train_dataset = datasets.CIFAR100(data_dir, train=True, download=True,
                                         transform=apply_transform)

        test_dataset = datasets.CIFAR100(data_dir, train=False, download=True,
                                        transform=apply_transform)

    elif args.dataset == 'mnist' or 'fmnist':
        if args.dataset == 'mnist':
            data_dir = '../data/mnist/'
        else:
            data_dir = '../data/fmnist/'

        apply_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        train_dataset = datasets.MNIST(data_dir, train=True, download=True,
                                       transform=apply_transform)

        test_dataset = datasets.MNIST(data_dir, train=False, download=True,
                                      transform=apply_transform)


    return train_dataset, test_dataset,

#生成shadow模型的数据集合
def shadow_dataset_generate(query_dic):
    shadowDataLoader = DataLoader(query_dic,batch_size=64)
    return shadowDataLoader #处理过的dataset(label值被子模型预测值替代)

#打开batch组，模拟query过程
def unpickle(file):
    with open(file, 'rb') as fo:
        dicte = pickle.load(fo, encoding='bytes')
    return dicte

def average_weights(w):
    """
    Returns the average of the weights.
    """
    w_avg = copy.deepcopy(w[0])
    for key in w_avg.keys():
        for i in range(1, len(w)):
            w_avg[key] += w[i][key]
        w_avg[key] = torch.div(w_avg[key], len(w))
    return w_avg



def get_shadow_train_loader():
    data_dir = '../data/mnist/'
    train_dataset2 = datasets.MNIST(data_dir, train=True, download=True,
                                     transform=transforms.Compose([
                                         transforms.Resize(28),
                                         transforms.CenterCrop(28),
                                         transforms.Grayscale(),
                                         transforms.ToTensor(),
                                         transforms.Normalize((0.1307,), (0.3081,)),
                                     ]))
    train_set = []
    query_list = np.random.choice(range(0, 50000),1200, replace=False) #假设1200次query
    for i in query_list:
        temp = train_dataset2.__getitem__(i)[0]
        train_set.append(temp)

    return query_list,train_set



# def get_shadow_train_loader():
#     dicte = unpickle("../data/cifar/cifar-10-batches-py/data_batch_1")
#     F_data = dicte[b'data']
#     datas = []
#     data1 = []
#     samples = []
#
#     for item in dicte:
#         item = trans(item)
#         datas.append(item)
#     labels = dicte[b'labels']
#     batch_dictionary = list(zip(datas, labels))
#     # print(batch_dictionary[2][0])#所有batch1中的数据
#
#     return batch_dictionary

def get_shadow_dataloader_WITHORI(shadow_data):
    dicte = unpickle("../MIA/dataset/cifar/cifar-10-batches-py/data_batch_1")
    ori_data = dicte[b'data']
    labels = dicte[b'labels']
    samples = []
    sample = []
    batch_dictionary = list(zip(ori_data, labels))
    sample = random.sample(batch_dictionary, 1600)	# 取样1600个原始数据，作为攻击者拥有源数据情况下的训练集合,
    for item in shadow_data:
        temp = [0,0]
        a = item[0]
        x = batch_dictionary[a-1]
        temp[0] = x[0]
        temp[1] = item[1]
        sample.append(temp)

    return sample


def get_shadow_dataloader_NOORI(shadow_data):
    dicte = unpickle("../MIA/dataset/cifar/cifar-10-batches-py/data_batch_1")
    ori_data = dicte[b'data']
    labels = dicte[b'labels']
    sample = []
    batch_dictionary = list(zip(ori_data, labels))
    for item in shadow_data:
        temp = [0,0]
        a = item[0]
        x = batch_dictionary[a-1]
        temp[0] = x[0]
        temp[1] = item[1]
        sample.append(temp)

    return sample #共640个数据样本




def exp_details(args):
    print('\n Experimental details:')
    print(f'    Model     : {args.model}')
    print(f'    Optimizer : {args.optimizer}')
    print(f'    Learning  : {args.lr}')
    print(f'    Global Rounds   : {args.epochs}\n')

    print('    Federated parameters:')
    if args.iid:
        print('    IID')
    else:
        print('    Non-IID')
    print(f'    Fraction of users  : {args.frac}')
    print(f'    Local Batch size   : {args.local_bs}')
    print(f'    Local Epochs       : {args.local_ep}\n')
    return

if __name__ == '__main__':
    get_shadow_train_loader()
